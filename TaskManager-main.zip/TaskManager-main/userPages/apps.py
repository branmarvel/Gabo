from django.apps import AppConfig


class UserpagesConfig(AppConfig):
    name = 'userPages'
