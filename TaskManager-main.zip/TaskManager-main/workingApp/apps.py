from django.apps import AppConfig


class WorkingappConfig(AppConfig):
    name = 'workingApp'
