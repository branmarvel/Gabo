from django.contrib import admin
from . import models
# admin.site.register(models.List_board)
admin.site.register(models.TaskList)
# admin.site.register(models.Task)